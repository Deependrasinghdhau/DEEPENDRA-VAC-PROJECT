import React from 'react'

const Header = () => {
  return (
    <div className='hnav'>
        <h1>VAC Project Pokemon App</h1>
    </div>
  )
}

export default Header